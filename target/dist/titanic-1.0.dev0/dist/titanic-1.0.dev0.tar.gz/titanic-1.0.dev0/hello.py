def helloworld():
    print("Hello world of Python\n")